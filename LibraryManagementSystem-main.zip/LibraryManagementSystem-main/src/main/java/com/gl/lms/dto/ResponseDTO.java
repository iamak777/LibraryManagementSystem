package com.gl.lms.dto;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatusCode;

@Setter
@Getter
@NoArgsConstructor
public class ResponseDTO  {

    private String message;


}
