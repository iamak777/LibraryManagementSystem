package com.gl.lms.exception;

import com.gl.lms.LibraryManagementSystemApplication;

public class LibraryManagementSystemException extends Exception{

    public LibraryManagementSystemException(String message) {
        super(message);
    }

}
