package com.gl.lms.repository;

import com.gl.lms.entity.LibraryCards;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibraryCardsRepository extends JpaRepository<LibraryCards, Integer> {

}
